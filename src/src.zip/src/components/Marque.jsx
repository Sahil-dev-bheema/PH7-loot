import React, { useMemo } from "react";

const DEFAULT_ITEMS = [
  { brand: "La Primitiva", amount: "9.43" },
  { brand: "La Primitiva", amount: "1.18" },
  { brand: "La Primitiva", amount: "1.18" },
  { brand: "SuperEnamax", amount: "5.89" },
  { brand: "SuperEnalotto", amount: "5.00" },
  { brand: "SuperEnalotto", amount: "8.07" },
];

export default function Marque({
  title = "Recent Winners",
  speed = 28,
  items = DEFAULT_ITEMS,
}) {
  const loop = useMemo(() => [...items, ...items], [items]);

  return (
    <div className="w-full border-y border-slate-200 bg-gradient-to-r from-emerald-50 via-white to-emerald-50">
      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
        .marquee-track {
          animation: marquee linear infinite;
          animation-duration: ${speed}s;
        }
        .marquee:hover .marquee-track { animation-play-state: paused; }
      `}</style>

      <div className="marquee flex items-center overflow-hidden">
        {/* Left label */}
        <div className="shrink-0 px-5 py-3 font-extrabold text-emerald-700 bg-white/80 backdrop-blur-md border-r border-emerald-200 tracking-wide">
          🏆 {title}
        </div>

        {/* Right scrolling area */}
        <div className="relative flex-1 overflow-hidden">
          {/* fade edges */}
          <div className="pointer-events-none absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-emerald-50 to-transparent z-10" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-emerald-50 to-transparent z-10" />

          <div className="marquee-track flex w-[200%]">
            <div className="flex w-1/2">
              {loop.map((x, i) => (
                <Winner key={i} {...x} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Winner({ brand, amount }) {
  const initials = (brand || "LG").slice(0, 2).toUpperCase();

  return (
    <div className="px-3 py-3">
      <div className="flex items-center gap-4 rounded-full bg-white/80 backdrop-blur-md border border-emerald-200 shadow-md hover:shadow-lg transition-shadow px-5 py-3">
        {/* icon */}
        <div className="h-9 w-9 rounded-full bg-gradient-to-br from-emerald-500 to-green-600 text-white grid place-items-center text-sm font-extrabold shadow">
          {initials}
        </div>

        {/* text */}
        <div className="whitespace-nowrap leading-tight">
          <div className="font-semibold text-slate-800 text-sm">
            {brand}
          </div>
          <div className="text-sm font-extrabold text-emerald-600 tracking-wide">
            ₹ {amount}
          </div>
        </div>

        {/* badge */}
        <span className="ml-2 text-[10px] font-bold text-white bg-emerald-500 px-2 py-1 rounded-full">
          WIN
        </span>
      </div>
    </div>
  );
}
