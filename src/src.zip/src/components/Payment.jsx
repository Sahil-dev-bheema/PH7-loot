import React, { useMemo, useState } from "react";
import axiosInstance from "../utils/axiosInstance";
import { SiPaytm, SiGooglepay, SiPhonepe } from "react-icons/si";

const cn = (...a) => a.filter(Boolean).join(" ");

const isValidUpi = (upi) =>
  /^[a-zA-Z0-9.\-_]{2,}@[a-zA-Z]{2,}$/.test(String(upi || "").trim());

const APP_META = [
  { id: "paytm", label: "Paytm", icon: SiPaytm },
  { id: "phonepe", label: "PhonePe", icon: SiPhonepe },
  { id: "gpay", label: "GPay", icon: SiGooglepay },
];

export default function Payment({
  open,
  onClose,
  onSubmit,
  userId = 1,
  amount = 0,
  title = "Selected Package",
  package_id = null,
}) {
  const [upiId, setUpiId] = useState("");
  const [provider, setProvider] = useState("");
  const [loading, setLoading] = useState(false);
  const [touched, setTouched] = useState({});

  if (!open) return null;

  const markTouched = (k) => setTouched((p) => ({ ...p, [k]: true }));

  const close = () => {
    if (loading) return;
    setUpiId("");
    setProvider("");
    setTouched({});
    onClose?.();
  };

  // ✅ Either-or selection rule
  const mode = useMemo(() => {
    const hasUpi = String(upiId || "").trim().length > 0;
    const hasApp = String(provider || "").trim().length > 0;
    if (hasUpi) return "upi";
    if (hasApp) return "app";
    return "none";
  }, [upiId, provider]);

  const errors = useMemo(() => {
    const amtOk = Number(amount) > 0;
    const pkgOk = Boolean(package_id);

    const hasUpi = String(upiId || "").trim().length > 0;
    const hasApp = String(provider || "").trim().length > 0;

    // mutually exclusive (should not happen because we clear, but safety)
    const both = hasUpi && hasApp;

    return {
      package_id: !pkgOk ? "Package not selected" : null,
      amount: !amtOk ? "Invalid amount" : null,

      // user must choose exactly one
      method:
        both
          ? "Choose only ONE method (UPI or Payment App)"
          : !hasUpi && !hasApp
          ? "Select Payment App OR enter UPI ID"
          : null,

      upiId:
        hasUpi && !isValidUpi(upiId) ? "Invalid UPI ID (ex: name@bank)" : null,

      provider: null,
    };
  }, [amount, package_id, provider, upiId]);

  const handlePay = async () => {
    markTouched("method");
    markTouched("upiId");
    markTouched("provider");

    if (errors.package_id || errors.amount || errors.method || errors.upiId) {
      if (errors.package_id) alert(errors.package_id);
      if (errors.amount) alert(errors.amount);
      return;
    }

    const amt = Number(amount);

    try {
      setLoading(true);

      // ✅ selected payment method details
      const meta =
        mode === "upi"
          ? { method: "upi", upiId: upiId.trim(), title }
          : { method: "app", provider, title };

      // 1) Create order
      const { data } = await axiosInstance.post(`/payment/create-order`, {
        userId,
        amount: amt,
        package_id,
        meta,
      });

      if (!data?.success || !data?.order?.id) {
        alert("Order creation failed");
        return;
      }

      const orderId = data.order.id;

      const ok = window.confirm(`Pay ₹${amt}? (Dummy Payment)`);
      if (!ok) return;

      // 2) Verify payment
      const paymentId = "pay_dummy_" + Date.now();

      const verifyRes = await axiosInstance.post(`/payment/verify`, {
        userId,
        order_id: orderId,
        payment_id: paymentId,
        amount: amt,
        package_id,
        meta,
      });

      if (verifyRes?.data?.success) {
        alert("✅ Payment Successful");
        onSubmit?.({
          userId,
          orderId,
          paymentId,
          amount: amt,
          package_id,
          meta,
        });
        close();
      } else {
        alert(verifyRes?.data?.message || "Payment failed");
      }
    } catch (err) {
      alert(err?.response?.data?.message || err?.message || "Payment error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999]">
      <div className="absolute inset-0 bg-black/40" onClick={close} />

      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-3xl bg-white shadow-xl ring-1 ring-slate-200 overflow-hidden">
          {/* Header */}
          <div className="px-5 py-4 border-b border-slate-100 flex justify-between items-start">
            <div>
              <p className="font-extrabold text-slate-900">Payment</p>
              <p className="text-xs text-slate-500">Buy Package</p>
            </div>

            <button
              onClick={close}
              disabled={loading}
              className="text-sm px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 transition disabled:opacity-60"
              type="button"
            >
              Close
            </button>
          </div>

          {/* Body */}
          <div className="p-5">
            <p className="text-sm text-slate-600">Purchasing:</p>
            <p className="font-extrabold text-lg text-slate-900">{title}</p>

            <div className="mt-4 rounded-2xl ring-1 ring-slate-200 bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Amount</p>
              <p className="text-3xl font-extrabold text-slate-900">
                ₹{Number(amount).toLocaleString("en-IN")}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Package ID:{" "}
                <span className="font-semibold text-slate-700">
                  {package_id ?? "—"}
                </span>
              </p>
            </div>

            {/* Method error */}
            {touched.method && errors.method ? (
              <div className="mt-4 rounded-2xl bg-rose-50 ring-1 ring-rose-200 p-3">
                <p className="text-sm font-semibold text-rose-700">
                  {errors.method}
                </p>
              </div>
            ) : null}

            {/* Payment App (selecting app clears UPI) */}
            <div className="mt-4">
              <p className="text-sm font-semibold text-slate-900">
                Pay using App
                <span className="text-xs text-slate-500 font-medium">
                  {" "}
                  (select one)
                </span>
              </p>

              <div className="mt-2 grid grid-cols-3 gap-2">
                {APP_META.map(({ id, label, icon: Icon }) => {
                  const active = provider === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      disabled={loading || mode === "upi"} // ✅ lock when UPI is chosen
                      onClick={() => {
                        setProvider(id);
                        setUpiId(""); // ✅ clear UPI (either-or)
                        markTouched("method");
                        markTouched("provider");
                      }}
                      className={cn(
                        "rounded-2xl border px-3 py-2.5 transition flex flex-col items-center justify-center gap-1",
                        active
                          ? "border-teal-400 bg-teal-50"
                          : "border-slate-200 bg-white hover:bg-slate-50",
                        mode === "upi" ? "opacity-50 cursor-not-allowed" : ""
                      )}
                    >
                      <Icon className={cn("text-xl", active ? "text-teal-600" : "text-slate-700")} />
                      <span className="text-xs font-semibold">{label}</span>
                    </button>
                  );
                })}
              </div>

              {mode === "upi" ? (
                <p className="text-[11px] text-slate-500 mt-2">
                  App selection disabled because you entered a UPI ID.
                </p>
              ) : null}
            </div>

            {/* Divider */}
            <div className="my-5 flex items-center gap-3">
              <div className="h-px bg-slate-200 flex-1" />
              <span className="text-xs font-semibold text-slate-500">OR</span>
              <div className="h-px bg-slate-200 flex-1" />
            </div>

            {/* UPI (typing UPI clears app) */}
            <div>
              <label className="text-sm font-semibold text-slate-900">
                Pay using UPI ID
              </label>
              <input
                value={upiId}
                onChange={(e) => {
                  const v = e.target.value;
                  setUpiId(v);
                  if (v.trim()) setProvider(""); // ✅ clear app (either-or)
                }}
                onBlur={() => {
                  markTouched("upiId");
                  markTouched("method");
                }}
                placeholder="name@bank"
                disabled={loading || mode === "app"} // ✅ lock when app is chosen
                className={cn(
                  "mt-2 w-full rounded-2xl px-4 py-3 outline-none border transition",
                  touched.upiId && errors.upiId
                    ? "border-red-500"
                    : "border-slate-200 focus:border-teal-400",
                  mode === "app" ? "bg-slate-50 opacity-60 cursor-not-allowed" : "bg-white"
                )}
              />

              {mode === "app" ? (
                <p className="text-[11px] text-slate-500 mt-2">
                  UPI input disabled because you selected a payment app.
                </p>
              ) : null}

              {touched.upiId && errors.upiId ? (
                <p className="text-xs text-red-600 mt-1">{errors.upiId}</p>
              ) : null}
            </div>

            {/* Pay */}
            <button
              onClick={handlePay}
              disabled={loading}
              className="w-full mt-6 py-3 rounded-2xl text-white font-semibold bg-teal-500 hover:bg-teal-600 disabled:opacity-60 transition"
              type="button"
            >
              {loading ? "Processing..." : "Pay Now"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
