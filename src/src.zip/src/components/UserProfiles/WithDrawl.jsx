import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import axiosInstance from "../../utils/axiosInstance";
import { useAuth } from "../../context/AuthContext";

const fmtMoney = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(Number(n || 0));

export default function WithDrawl({ open, onClose }) {
  const { user, wallet, updateWallet } = useAuth();

  const total = useMemo(
    () => Number(wallet?.cash ?? 0) + Number(wallet?.bonus ?? 0),
    [wallet?.cash, wallet?.bonus]
  );

const handleWithdrawClick = () => {
  if (!canSubmit || submitting) return;

  const ok = window.confirm(
    "Are you sure you want to withdraw this money?"
  );

  if (ok) {
    submitWithdraw();
  }
};

  const [amount, setAmount] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!open) return;
    setAmount("");
    setErr("");
  }, [open]);

  /* ESC close */
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose?.();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  /* lock scroll */
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => (document.body.style.overflow = prev);
  }, [open]);

  const maxCoins = Math.max(0, total);
  const nAmount = Number(amount);

  const canSubmit =
    !submitting &&
    user &&
    amount !== "" &&
    Number.isFinite(nAmount) &&
    nAmount > 0 &&
    nAmount <= maxCoins;

  /* ✅ Withdraw logic */
  const submitWithdraw = async () => {
    if (!canSubmit) return;

    setSubmitting(true);
    setErr("");

    const prevWallet = { ...wallet };

    try {
      const currentCash = Number(wallet?.cash ?? 0);
      const currentBonus = Number(wallet?.bonus ?? 0);

      let remaining = nAmount;
      let newCash = currentCash;
      let newBonus = currentBonus;

      // withdraw from cash first
      const fromCash = Math.min(newCash, remaining);
      newCash -= fromCash;
      remaining -= fromCash;

      // then bonus
      const fromBonus = Math.min(newBonus, remaining);
      newBonus -= fromBonus;
      remaining -= fromBonus;

      if (remaining > 0) {
        setErr("Insufficient balance.");
        setSubmitting(false);
        return;
      }

      /* ✅ instant UI update */
      updateWallet({
        cash: newCash,
        bonus: newBonus,
      });

      /* backend sync */
      const res = await axiosInstance.post("/payment/withdraw", {
        userId: user?._id || user?.id,
        amount: nAmount,
      });

      /* if backend sends wallet, use it */
      const serverWallet =
        res?.data?.wallet || res?.data?.data?.wallet;

      if (serverWallet) {
        updateWallet(serverWallet);
      }

      onClose?.();
    } catch (e) {
      /* rollback */
      updateWallet(prevWallet);

      setErr(
        e?.response?.data?.message ||
          e?.message ||
          "Withdraw failed"
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-[9999]">
      {/* overlay */}
      <div
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-md"
        onClick={onClose}
      />

      {/* modal */}
      <div className="absolute inset-0 flex items-center justify-center p-3 sm:p-6">
        <div className="w-full max-w-lg rounded-[28px] overflow-hidden bg-white ring-1 ring-slate-200 shadow-2xl">
          {/* header */}
          <div className="relative border-b border-slate-100">
            <div className="absolute inset-0 bg-gradient-to-b from-slate-50 via-white to-white pointer-events-none" />

            <div className="relative px-5 py-4 flex items-start justify-between gap-3">
              <div>
                <p className="text-base sm:text-lg font-extrabold text-slate-900">
                  Withdraw Coins
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Available:{" "}
                  <span className="font-semibold text-slate-700">
                    {fmtMoney(maxCoins)}
                  </span>
                </p>
              </div>

              <button
                onClick={onClose}
                className="shrink-0 rounded-2xl px-3 py-2 text-sm font-semibold bg-slate-900 text-white hover:bg-slate-800 active:scale-[0.98] transition"
              >
                Close
              </button>
            </div>
          </div>

          {/* body */}
          <div className="p-5 space-y-4">
            {err ? (
              <div className="rounded-2xl bg-rose-50 p-3 ring-1 ring-rose-200">
                <p className="text-sm font-semibold text-rose-700">{err}</p>
              </div>
            ) : null}

            <div className="rounded-3xl bg-slate-50 ring-1 ring-slate-200 p-4">
              <p className="text-xs font-semibold text-slate-600">
                Enter amount
              </p>

              <div className="mt-3 flex gap-2">
                <input
                  type="number"
                  min={1}
                  max={maxCoins}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="e.g. 500"
                  className="w-full rounded-2xl px-4 py-3 bg-white ring-1 ring-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-300 text-sm font-semibold"
                />

                <button
                  type="button"
                  onClick={() => setAmount(String(maxCoins))}
                  className="rounded-2xl px-4 py-3 text-sm font-semibold bg-white ring-1 ring-slate-200 hover:bg-slate-100 transition"
                >
                  Max
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-white ring-1 ring-slate-200 p-3">
                <p className="text-[11px] text-slate-500">
                  Wallet Total
                </p>
                <p className="mt-1 font-extrabold text-slate-900">
                  {fmtMoney(maxCoins)}
                </p>
              </div>

              <div className="rounded-2xl bg-white ring-1 ring-slate-200 p-3">
                <p className="text-[11px] text-slate-500">
                  Withdraw Amount
                </p>
                <p className="mt-1 font-extrabold text-slate-900">
                  {fmtMoney(Number.isFinite(nAmount) ? nAmount : 0)}
                </p>
              </div>
            </div>
          </div>

          {/* footer */}
          <div className="border-t border-slate-100 bg-white px-5 py-4 flex items-center justify-between">
            <p className="text-xs text-slate-500">
              Press <span className="font-semibold">Esc</span> to close
            </p>

            <button
              onClick={handleWithdrawClick}
              disabled={!canSubmit}
              className={[
                "rounded-2xl px-5 py-2.5 text-sm font-semibold transition",
                canSubmit
                  ? "bg-emerald-600 text-white hover:bg-emerald-500"
                  : "bg-slate-200 text-slate-500 cursor-not-allowed",
              ].join(" ")}
            >
              {submitting ? "Withdrawing..." : "Withdraw"}
              
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
